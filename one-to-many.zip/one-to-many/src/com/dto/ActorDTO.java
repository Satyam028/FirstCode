package com.dto;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "Actor_table")
public class ActorDTO implements Serializable {

	@Id
	@GenericGenerator(name = "auto", strategy = "increment")
	@GeneratedValue(generator = "auto")
	@Column(name = "actor_id")
	private int actorId;
	@Column(name = "actor_name")
	private String actorName;
	@Column(name = "actor_sal")
	private double actorSal;
	@Column(name = "actor_age")
	private int actorAge;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "actorDTO", fetch = FetchType.LAZY)
	private List<FanDTO> listFanDTO;

	public ActorDTO() {
		System.out.println(this.getClass().getSimpleName() + " object created");
	}

	public int getActorId() {
		return actorId;
	}

	public void setActorId(int actorId) {
		this.actorId = actorId;
	}

	public String getActorName() {
		return actorName;
	}

	public void setActorName(String actorName) {
		this.actorName = actorName;
	}

	public double getActorSal() {
		return actorSal;
	}

	public void setActorSal(double actorSal) {
		this.actorSal = actorSal;
	}

	public int getActorAge() {
		return actorAge;
	}

	public void setActorAge(int actorAge) {
		this.actorAge = actorAge;
	}

	public List<FanDTO> getListFanDTO() {
		return listFanDTO;
	}

	public void setListFanDTO(List<FanDTO> listFanDTO) {
		this.listFanDTO = listFanDTO;
	}

}
