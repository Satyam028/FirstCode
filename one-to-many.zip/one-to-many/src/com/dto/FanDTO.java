package com.dto;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "Fan_table")
public class FanDTO implements Serializable {

	@Id
	@GenericGenerator(name = "auto", strategy = "increment")
	@GeneratedValue(generator = "auto")
	@Column(name = "fan_id")
	private int fanId;
	@Column(name = "fan_name")
	private String fanName;
	@Column(name = "fan_age")
	private int fanAge;

	@ManyToOne(cascade = { CascadeType.DETACH, CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH })

	@JoinColumn(name = "actor_id")
	private ActorDTO actorDTO;

	public int getFanId() {
		return fanId;
	}

	public void setFanId(int fanId) {
		this.fanId = fanId;
	}

	public String getFanName() {
		return fanName;
	}

	public void setFanName(String fanName) {
		this.fanName = fanName;
	}

	public int getFanAge() {
		return fanAge;
	}

	public void setFanAge(int fanAge) {
		this.fanAge = fanAge;
	}

	public ActorDTO getActorDTO() {
		return actorDTO;
	}

	public void setActorDTO(ActorDTO actorDTO) {
		this.actorDTO = actorDTO;
	}

}
