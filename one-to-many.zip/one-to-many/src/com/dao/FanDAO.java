package com.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.dto.FanDTO;
import com.util.HibernateUtil;

public class FanDAO {

	SessionFactory factory = HibernateUtil.getSessionfactory();

	public void saveDetailsOffan(List<FanDTO> listFanDTO) {
		Transaction transaction = null;
		try (Session session = factory.openSession()) {
			transaction = session.beginTransaction();
			for (FanDTO fanDTO : listFanDTO) {
				session.persist(fanDTO);
			}
			transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		}
	}
}
