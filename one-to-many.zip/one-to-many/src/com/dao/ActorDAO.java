package com.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.dto.ActorDTO;
import com.util.HibernateUtil;

public class ActorDAO {

	SessionFactory factory = HibernateUtil.getSessionfactory();

	public void saveDetailsOfActor(ActorDTO actorDTO) {
		Transaction transaction = null;

		try (Session session = factory.openSession()) {
			transaction = session.beginTransaction();
			session.save(actorDTO);
			transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		}
	}

}
