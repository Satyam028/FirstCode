package com.util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {
	private static final SessionFactory sessionfactory;

	static {
		Configuration config = new Configuration();
		config.configure();
		sessionfactory = config.buildSessionFactory();
	}

	public static SessionFactory getSessionfactory() {
		return sessionfactory;
	}

}
