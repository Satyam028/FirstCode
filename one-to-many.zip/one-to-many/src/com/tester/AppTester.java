package com.tester;

import java.util.ArrayList;
import java.util.List;

import com.dao.FanDAO;
import com.dto.ActorDTO;
import com.dto.FanDTO;

public class AppTester {
	public static void main(String[] args) {

		ActorDTO actorDTO = new ActorDTO();
		actorDTO.setActorName("Sallu");
		actorDTO.setActorAge(52);
		actorDTO.setActorSal(40000);

		FanDTO fanDTO = new FanDTO();
		fanDTO.setFanName("Rohan");
		fanDTO.setFanAge(23);
		fanDTO.setActorDTO(actorDTO);

		FanDTO fanDTO1 = new FanDTO();
		fanDTO1.setFanName("Satyam");
		fanDTO1.setFanAge(23);
		fanDTO1.setActorDTO(actorDTO);

		FanDTO fanDTO2 = new FanDTO();
		fanDTO2.setFanName("Amod");
		fanDTO2.setFanAge(23);
		fanDTO2.setActorDTO(actorDTO);

		FanDTO fanDTO3 = new FanDTO();
		fanDTO3.setFanName("Laxmi");
		fanDTO3.setFanAge(53);
		fanDTO3.setActorDTO(actorDTO);

		List<FanDTO> fanList = new ArrayList<>();

		fanList.add(fanDTO);
		fanList.add(fanDTO1);
		fanList.add(fanDTO2);
		fanList.add(fanDTO3);

		FanDAO fanDAO = new FanDAO();
		fanDAO.saveDetailsOffan(fanList);

	}

}
